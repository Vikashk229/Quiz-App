package com

object setData {

    const val name:String="name"
    const val score:String="score"

    fun getQuestion():ArrayList<QuestionData>{
        var que:ArrayList<QuestionData> = arrayListOf()

        var question1=QuestionData(
            1,
            "What is Capital City of India",
            "Mumbai",
            "Karnataka",
            "New Delhi",
            "Kerala",
            3
        )
        var question2 = QuestionData(
            2,
            "Who is the 1st king of India",
            "Chandragupta Maurya",
            "Krishnadevaraya",
            "Pruthvi Raj Chawan",
            "Ashoka chakravarthy",
            1
        )
        var question3=QuestionData(
            3,
            "Who developed kotlin Language",
            "Oracle",
            "JetBrains",
            "Google",
            "Microsoft",
            2
        )
        var question4=QuestionData(
            4,
            "Who is the current PM of India",
            "Amith sha",
            "Baba Ramdev",
            "ManaMohan Singh",
            "Narendra Modi",
            4
        )
        var question5=QuestionData(
            5,
            "Which is the World's Largest Flower",
            "Sunflower",
            "Rose",
            "Rafflesia",
            "Marie Gold",
            3
        )
        que.add(question1)
        que.add(question2)
        que.add(question3)
        que.add(question4)
        que.add(question5)
        return que
    }
}